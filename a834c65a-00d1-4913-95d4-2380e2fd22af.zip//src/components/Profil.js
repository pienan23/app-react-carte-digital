import "../styles.css";
const link =
  "https://teamjapanese.com/wp-content/uploads/2022/03/girl-in-japanese.jpg";
export default function Profil() {
  return (
    <div className="profil">
      <img src={link} alt="" />
    </div>
  );
}
