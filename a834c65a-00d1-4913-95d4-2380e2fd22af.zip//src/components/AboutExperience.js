import "../styles.css";

export default function AboutExperience() {
  return (
    <>
      <section className="about">
        <h1>About</h1>
        <p>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nisi odit
          deserunt sint neque, totam quibusdam voluptate natus non nulla eaque
          ut magnam ad repellat et vel perspiciatis maxime enim deleniti.
        </p>
      </section>

      <section className="experiences">
        <h1>Experiences</h1>
        <p>
          Lorem, ipsum dolor sit amet consectetur adipisicing elit. Nisi odit
          deserunt sint neque, totam quibusdam voluptate natus non nulla eaque
          ut magnam ad repellat et vel perspiciatis maxime enim deleniti.
        </p>
      </section>
    </>
  );
}
